$(document).ready(function () {
	init();

	$('.showInfo').on('click', function () {
		console.log('asdasdasd');
	});
});

const init = () => {
	getData();
};

const getData = async () => {
	const url = 'https://615485ee2473940017efaed3.mockapi.io/assessment';
	const response = await fetch(url);
	const data = await response.json();

	printData(data);
};

var source = $('#template').html();
var template = Handlebars.compile(source);

function printData(datas) {
	for (var i = 0; i < datas.length; i++) {
		var data = datas[i];

		var dataStamp = {
			userId: data.id,
			name: data.name,
			img: data.avatar,
			createdAt: data.createdAt,
		};

		var filled = template(dataStamp);
		$('.users-wrap').append(filled);
	}
}
