let taskInput = document.querySelector('.wrapNewTask #new-task');
let addButton = document.querySelector('.wrapNewTask > button');
let incompleteTasks = document.querySelector('#incomplete-tasks');
let completedTasks = document.getElementById('completed-tasks');

let unCompleteList = [],
	id = 0;

const tasks = JSON.parse(localStorage.getItem('taskListArr'));

if (tasks) {
	unCompleteList = tasks;
	loadLists(unCompleteList);
} else {
	unCompleteList = [];
}

function loadLists(tasksArr) {
	tasksArr.forEach((element, index) => {
		if (!element.complete === true) {
			incompletedTaskList(element);
		} else {
			completeTaskList(element);
		}
	});
}

document.addEventListener('keyup', function (event) {
	if (event.key == 'Enter') {
		const task = taskInput.value;
		if (task.length === 0) return;

		const newTask = {
			id,
			name: task,
			complete: false,
		};

		incompletedTaskList(newTask);
		unCompleteList.push(newTask);
		// console.log(unCompleteList);
		localStorage.setItem('taskListArr', JSON.stringify(unCompleteList));
		taskInput.value = '';
		id++;
	}
});

function incompletedTaskList(task) {
	// console.log(task);
	const content = templateTask(task);

	incompleteTasks.insertAdjacentHTML('beforeend', content);
}

function completeTaskList(task) {
	const content = templateTask(task);

	completedTasks.insertAdjacentHTML('beforeend', content);
}

const completeTask = function (element) {
	const liItem = element.parentNode.parentNode;

	const elementId = Number(liItem.querySelector('input').id);
	const newTasks = unCompleteList.map((task) => {
		if (task.id === elementId) {
			task.complete = !task.complete;

			if (!task.complete) {
				incompletedTaskList(task);
			} else {
				completeTaskList(task);
			}
		}

		return task;
	});

	unCompleteList = newTasks;
	localStorage.setItem('taskListArr', JSON.stringify(unCompleteList));

	liItem.remove();
};

incompleteTasks.addEventListener('click', function (event) {
	const element = event.target;
	const elementJob = element.attributes.job.value;

	if (elementJob == 'complete') {
		completeTask(element);
	} else if (elementJob == 'edit') {
		const liItem = element.parentNode.parentNode;
		liItem.classList.toggle('editMode');
		const editInput = liItem.querySelector('input[type=text]');
		const btn = liItem.querySelector('button.edit');
		const label = liItem.querySelector('label');

		btn.innerText = liItem.classList.contains('editMode') ? 'Save' : 'Edit';

		const containsClass = liItem.classList.contains('editMode');
		const arrList = JSON.parse(localStorage.getItem('taskListArr'));

		if (!containsClass) {
			for (let i = 0; i < arrList.length; i++) {
				if (arrList[i].id === Number(element.id)) {
					arrList[i].name = editInput.value;

					localStorage.setItem('taskListArr', JSON.stringify(arrList));

					label.innerText = editInput.value;
				}
			}
		} else {
			editInput.value = label.innerText;
		}
	} else if (elementJob == 'delete') {
		deleteTask(element);
	}
});

completedTasks.addEventListener('click', function (event) {
	const element = event.target;
	const elementJob = element.attributes.job.value;

	if (elementJob == 'incomplete') {
		completeTask(element);
	} else if (elementJob == 'delete') {
		deleteTask(element);
	}
});

function deleteTask(element) {
	const confirmD = confirm('Are you sure to delete this item?');
	if (confirmD) {
		const liItem = element.parentNode.parentNode;
		const newArr = JSON.parse(localStorage.getItem('taskListArr')).filter(
			(task) => task.id !== Number(element.id)
		);

		localStorage.setItem('taskListArr', JSON.stringify(newArr));
		liItem.remove();
	}
}

function templateTask(task) {
	return `
		<li>
			<div>
				<input
					type="checkbox"
					job="${task.complete ? 'incomplete' : 'complete'}"
					id="${task.id}"
					${task.complete ? 'checked' : null}>
				<label>${task.name}</label>
				<input type="text">
			</div>
			<div>
				<button class="edit" job="edit" id="${task.id}">Edit</button>
				<button class="delete" job="delete" id="${task.id}">Delete</button>
			</div>
		</li>
	`;
}
